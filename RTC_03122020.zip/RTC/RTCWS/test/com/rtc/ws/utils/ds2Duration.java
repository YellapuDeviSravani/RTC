package com.rtc.ws.utils;

import org.tritonus.share.sampled.file.TAudioFileFormat;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.File;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ds2Duration{
    private static final Logger LOG = Logger.getLogger(ds2Duration.class.getName());
    private static final int	LOAD_METHOD_STREAM = 1;
    private static final int	LOAD_METHOD_FILE = 2;
    private static final int	LOAD_METHOD_URL = 3;

    public static void main(String[] args){
        AudioInputStream stream = null;
        try{
            String line;
            //String ds2File = "D:\\Sample.ds2";

            File file = new File("D:\\Sample.ds2");

            AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(file);
            if (fileFormat instanceof TAudioFileFormat) {
                LOG.log(Level.INFO, "***********Found valid audio file format(DS2)");

                Map<?, ?> properties = ((TAudioFileFormat) fileFormat).properties();
                String key = "duration";

                if(null == properties.get(key)){
                    LOG.log(Level.SEVERE, "***********No duration property is found");
                    throw new Exception("No duration property is found for " + file.getName());
                }

                Long microseconds = (Long) properties.get(key);
                long milli = (long)microseconds / 1000;

                LOG.log(Level.INFO, "***********Calculated Duration of DS2 file: " + file.getAbsolutePath() + " is " + milli + " milliSeconds");
                //return milli;
            } else {
                LOG.log(Level.SEVERE, "***********Unsupported DS2 file: " + file.getAbsolutePath());
                throw new UnsupportedAudioFileException();
            }
            /*AudioFileFormat baseFileFormat = new MpegAudioFileReader().getAudioFileFormat(file);
            Map properties = baseFileFormat.properties();
            Long duration = (Long) properties.get("duration");
            System.out.println(duration);*/

        }
        /*catch(IOException | InterruptedException e){
            LOG.log(Level.SEVERE, null, e);
        }*/

        catch(Exception e){
            System.out.println("cannot open input file");
            e.printStackTrace();
            return;
        }

    }
}