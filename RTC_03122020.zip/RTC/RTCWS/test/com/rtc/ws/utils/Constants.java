package com.rtc.ws.utils;

public interface Constants {
	/* RTC OWN SFTP SERVER DETAILS: BEGIN */
	
	String p_dest_hostname = "localhost";
	int p_dest_port = 22;
	String p_dest_username = "";
	String p_dest_password = "";
	String p_dest_Folder = "/download";
	String p_dest_Path_to_Root = "/";
	String path_to_ffmpeg_bin = "/Volumes/My Backup/Apps/ffmpeg-4.0-macos64-static/bin/";
	/* RTC OWN SFTP SERVER DETAILS: END */
	
}
